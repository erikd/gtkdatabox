#!/bin/sh

aclocal
libtoolize -c -f --automake
autoheader 
autoconf
automake --add-missing
automake

