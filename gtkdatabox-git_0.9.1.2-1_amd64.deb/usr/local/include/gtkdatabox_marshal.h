/* $Id: gtkdatabox_marshal.h 4 2008-06-22 09:19:11Z rbock $ */

#ifndef __gtk_databox_marshal_MARSHAL_H__
#define __gtk_databox_marshal_MARSHAL_H__

#include	<glib-object.h>

G_BEGIN_DECLS
/* VOID:VOID (gtkdatabox_marshal.list:1) */
#define gtk_databox_marshal_VOID__VOID	g_cclosure_marshal_VOID__VOID
/* VOID:POINTER (gtkdatabox_marshal.list:2) */
#define gtk_databox_marshal_VOID__POINTER	g_cclosure_marshal_VOID__POINTER
   G_END_DECLS
#endif /* __gtk_databox_marshal_MARSHAL_H__ */
